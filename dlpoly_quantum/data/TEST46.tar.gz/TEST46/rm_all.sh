#!/bin/bash
 
rm RDFDAT OUT* STATIS* FINAL_CONFIG.01 DIP* HISTORY stdout slur* REV*
