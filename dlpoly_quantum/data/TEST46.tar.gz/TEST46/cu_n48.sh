#!/bin/bash
#SBATCH -N 1
#SBATCH -p RM-shared 
#SBATCH --time 2:00:00
#SBATCH --ntasks-per-node 24
#SBATCH --mem=20000mb
#SBATCH --mail-user=momeni@njit.edu
#SBATCH --mail-type=ALL

module purge
module load intelmpi
module list

export EXE=/jet/home/shakib/codes/working_codes/dlpoly_quantum/execute/DLPOLY.X

##export PIMD_CMD_NUM_BEADS=1

mpiexec.hydra -bootstrap sge $EXE

##mpirun -np 24 $EXE

